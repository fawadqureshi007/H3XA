metadata = {
    "version": "2.3.4",
    "name": "🕷️  Spider Edition"
}